import logo from "../assets/logos/biy_logo_main.png"

const howItWorks = [
  {
    step: '01',
    title: 'Modul auswählen',
    text: 'Wähle das passende Bauteil aus der Modulübersicht und starte gezielt mit dem nächsten Bauabschnitt.',
  },
  {
    step: '02',
    title: 'Anleitung ansehen',
    text: 'Arbeite dich digital durch klare Schritte mit visuellen Hinweisen, Maßen und ergänzenden Medien.',
  },
  {
    step: '03',
    title: 'Bauteil umsetzen',
    text: 'Übertrage die Anleitung direkt in die Praxis und behalte Materialien, Werkzeuge und Ablauf im Blick.',
  },
]

const modulePreview = [
  {
    title: 'Wand',
    tag: 'W4 aktiv',
    text: 'Das erste verfügbare Modul mit ausgearbeiteter Anleitung für den direkten Einstieg.',
    active: true,
  },
  {
    title: 'Decke',
    tag: 'In Vorbereitung',
    text: 'Als nächstes Modul vorbereitet, um die Systemlogik schrittweise zu erweitern.',
    active: false,
  },
  {
    title: 'Dach',
    tag: 'In Vorbereitung',
    text: 'Geplant als weiterer Baustein für ein vollständig modulares Gesamtsystem.',
    active: false,
  },
]

const features = [
  'Schritt-für-Schritt Anleitung',
  'Bild + Maßdarstellung',
  'Videoanimation',
  'Materialien und Werkzeuge',
]

export default function LandingPage({ onStart }) {
  return (
    <section className="landing-page page-shell">
      <div className="landing-stack">
        <div className="hero-card">
          <div className="hero-copy">
            <div className="hero-logo">
              <img src={logo} alt="Build It Yourself" />
            </div>
            <div className="brand-row">
              <div>
                <p className="eyebrow">Modulares Bausystem</p>
                <h1>Build it yourself</h1>
              </div>
            </div>
            <p className="lead">
              Die digitale Schritt-für-Schritt-Anleitung für modulare Holzbauten. Von der Auswahl des
              Moduls bis zur Umsetzung auf der Baustelle begleitet dich das System klar, visuell und
              praxisnah.
            </p>
            <div className="hero-points">
              <span>Digitale Bauanleitung</span>
              <span>Modular aufgebaut</span>
              <span>Direkt nutzbar auf der Baustelle</span>
            </div>
            <div className="hero-actions">
              <button className="primary-btn" onClick={onStart}>
                Zur Modulübersicht
              </button>
              <a className="secondary-link" href="#how-it-works">
                So funktioniert das System
              </a>
            </div>
          </div>

          <div className="hero-visual" aria-label="Projekt-Render Platzhalter">
            <div className="visual-shell">
              <div className="visual-header">
                <span className="small-label">Projekt-Render</span>
                <span className="visual-status">Platzhalter</span>
              </div>

              <div className="visual-stage">
                <div className="visual-stage-grid" />

                <div className="visual-frame visual-frame--main">
                  <div className="frame-label">Gesamtvisualisierung</div>
                  <strong>Platzhalter für ein zukünftiges Render des Gesamtprojekts</strong>
                  <p>
                    Hier kann später eine hochwertige Außen- oder Systemansicht des modularen
                    Bausystems eingebunden werden.
                  </p>
                </div>

                <div className="visual-frame visual-frame--detail">
                  <span>Systemansicht</span>
                  <span>Module</span>
                  <span>Baulogik</span>
                </div>
              </div>

              <div className="visual-footer">
                <div>
                  <span className="visual-kicker">Status</span>
                  <strong>Render folgt</strong>
                </div>
                <div>
                  <span className="visual-kicker">Format</span>
                  <strong>Bild oder 3D-Export</strong>
                </div>
              </div>
            </div>
          </div>
        </div>

        <section id="how-it-works" className="landing-section info-section">
          <div className="section-heading">
            <p className="eyebrow">How it works</p>
            <h2>Vom Modul zur Umsetzung in drei klaren Schritten</h2>
            <p className="section-copy">
              Die Plattform führt Nutzer strukturiert durch Auswahl, Verständnis und praktische
              Ausführung.
            </p>
          </div>

          <div className="info-grid info-grid--three">
            {howItWorks.map((item) => (
              <article key={item.step} className="info-card">
                <span className="info-step">{item.step}</span>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="landing-section module-preview-section">
          <div className="section-heading">
            <p className="eyebrow">Module Preview</p>
            <h2>Ein erstes Modul ist bereit, weitere folgen im System</h2>
            <p className="section-copy">
              W4 ist als aktiver Einstieg verfügbar. Decke und Dach sind bereits als nächste
              Ausbaustufen vorgesehen.
            </p>
          </div>

          <div className="info-grid info-grid--three">
            {modulePreview.map((item) => (
              <article
                key={item.title}
                className={`info-card module-preview-card${
                  item.active ? ' module-preview-card--active' : ' module-preview-card--placeholder'
                }`}
              >
                <div className="module-preview-head">
                  <h3>{item.title}</h3>
                  <span className={`module-state${item.active ? ' module-state--active' : ''}`}>
                    {item.tag}
                  </span>
                </div>
                <p>{item.text}</p>
                <div className="module-preview-rail" aria-hidden="true">
                  <span />
                  <span />
                  <span />
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="landing-section features-section">
          <div className="section-heading">
            <p className="eyebrow">Features</p>
            <h2>Die wichtigsten Inhalte für eine nutzbare Bauanleitung</h2>
          </div>

          <div className="info-grid info-grid--four">
            {features.map((feature) => (
              <article key={feature} className="info-card feature-card">
                <span className="feature-marker" aria-hidden="true" />
                <h4>{feature}</h4>
              </article>
            ))}
          </div>
        </section>

        <section className="landing-section final-cta">
          <div className="final-cta-card">
            <div>
              <p className="eyebrow">Nächster Schritt</p>
              <h2>Starte mit dem ersten Modul und sieh dir den Ablauf im Detail an</h2>
            </div>
            <button className="primary-btn" onClick={onStart}>
              Zur Modulübersicht
            </button>
          </div>
        </section>
      </div>
    </section>
  )
}
